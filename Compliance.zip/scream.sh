#!/bin/bash
gtk-launch myScream.desktop
